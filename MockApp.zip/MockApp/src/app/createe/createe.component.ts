//import { Component, OnInit } from '@angular/core';
import { Component, OnInit } from '@angular/core';
// import { MatFormFieldModule } from '@angular/material/form-field';
// import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-createe',
  templateUrl: './createe.component.html',
  styleUrls: ['./createe.component.css']
})
export class CreateeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
