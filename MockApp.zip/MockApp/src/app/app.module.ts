import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateComponent } from './create/create.component';
import { DisplayComponent } from './display/display.component';

import { EmployeeService } from './employee.service';
import { CreateeComponent } from './createe/createe.component';
import { DisplayyComponent } from './displayy/displayy.component';

// import { MatFormFieldModule } from '@angular/material/form-field';
// import { MatInputModule } from '@angular/material/input';
// import {MdButtonModule, MdCheckboxModule} from '@angular/material';
// import {MdCardModule} from '@angular/material';
// import {MaterialModule} from '@angular/material';

@NgModule({
  declarations: [
    AppComponent,
    CreateComponent,
    DisplayComponent,
    CreateeComponent,
    DisplayyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    ReactiveFormsModule,
    // MatFormFieldModule,
    // MatInputModule
    // MdButtonModule, 
    // MdCheckboxModule,
    // MdCardModule,
    // MaterialModule
  ],
  providers: [EmployeeService],
  // providers: [
  //   {provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: {appearance: 'fill'}},{EmployeeService}
  // ],
  bootstrap: [AppComponent]
})
export class AppModule { }
