import { EmployeeService } from '../employee.service';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { EmployeeC } from '../employee.modelFi';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  constructor(public service: EmployeeService,
    private toastr: ToastrService) { }


    //private toastr: ToastrService

    
    list3:EmployeeC[];
    list:EmployeeC;

  ngOnInit(): void {
      // this.service.refreshList();
    this.refreshList();
    // this.service.refreshList().subscribe((data3)=>{
    //   this.list3=JSON.parse(JSON.stringify(data3))
    // })
  }

  refreshList(){
    //  this.service.refreshList().subscribe((data3)=>{
    //   this.list3=JSON.parse(JSON.stringify(data3))
    // })
    this.service.refreshList();
  }

  populateForm(emp: EmployeeC) {
    this.service.formData2 = Object.assign({}, emp); 
    //this.list=JSON.parse(JSON.stringify(this.service.formData2))

    //console.log(this.service.formData2)
    //alert(this.service.formData2.email);
    //this.toastr.warning(this.list.userName);
     //this.toastr.warning(this.service.formData2.email);

     this.toastr.warning(this.service.formData2.phone,this.service.formData2.gender);
     this.toastr.warning(this.service.formData2.email,this.service.formData2.userName);

    //M.toast({ html: 'Deleted successfully', classes: 'rounded' });
    //M.toast({ html: '<ol><li>'+this.list.userName+'</li><li>'+this.list.email+'</li><li>'+this.list.phone+'</li><li>'+this.list.gender+'</li><li>'+this.list.age+'</li></ol>', classes: 'rounded' });
    //alert("<h1>hello</h1>")
    //EmpModV=this.service.formData2;
    // if (confirm(this.service.formData2.email)){
    //   alert("hello")
    // }
  }

  onDelete(id: number) {
    if (confirm('Are you sure to delete this record?')) {
      this.service.deleteEmployee(id).subscribe(res => {
        //this.service.refreshList();
        this.refreshList();
        this.toastr.warning('Deleted successfully', 'EMP1. Register');
        // this.toastr.success('Hello world!', 'Toastr fun!');
      });
    }
  }

}
