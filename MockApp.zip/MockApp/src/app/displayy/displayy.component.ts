import { Component, OnInit } from '@angular/core';
//import {Component} from '@angular/core';

@Component({
  selector: 'app-displayy',
  templateUrl: './displayy.component.html',
  styleUrls: ['./displayy.component.css']
})
export class DisplayyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
