import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayyComponent } from './displayy.component';

describe('DisplayyComponent', () => {
  let component: DisplayyComponent;
  let fixture: ComponentFixture<DisplayyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
