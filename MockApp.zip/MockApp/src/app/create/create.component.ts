import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  isValidFormSubmitted = false;
  validateEmail = true;
  emailPattern0 = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  emailPattern=/^([A-Za-z0-9\.-]+)@([A-Za-z0-9\-]+).([a-z]{2,3})(.[a-z]{2,3})?$/

  constructor(public service: EmployeeService,
    private toastr: ToastrService) { }

  ngOnInit(): void {
    this.resetForm();
    this.service.refreshList();
  }
  resetForm(form?: NgForm) {
    if (form != null)     //if new data is there
    //if(form)
      form.resetForm();
    this.service.formData2 = {
      id: '',
      userName: '',
      email: '',
      phone: '',
      gender: '',
      age: null
    }
  }
  
  onSubmit(form: NgForm) {
    this.service.postEmployee(form.value).subscribe(res => {   //slow method i mean subscribe in component ts file
      console.log(form.value)                                  //only one letter is alloweded in gender field
      this.toastr.success('Inserted successfully', 'EMP2. Register');
      this.resetForm(form);
      this.service.refreshList();
    });
  }
  // onSubmit(form: NgForm){      //sometime not working,one letter in gender
  //   // this.service.postEmployee(this.service.formData2)
  //   this.service.postEmployee2(form.value);
  //     this.resetForm(form);
  //     this.service.refreshList(); 
  //     this.toastr.success('Inserted successfully', 'EMP2. Register');
  //     //console.log(form.value);
  // }
  

}
