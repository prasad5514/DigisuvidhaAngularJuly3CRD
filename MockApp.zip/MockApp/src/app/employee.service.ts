import { Injectable } from '@angular/core';
import { EmployeeC } from './employee.modelFi';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http : HttpClient) { }
  formData2 : EmployeeC;
  list2 : EmployeeC[];
  readonly rootURL2 ="https://dev.digisuvidhacentre.com/Profile/api/MockUser"

    postEmployee(formData2: EmployeeC){
    return this.http.post(this.rootURL2,formData2)

  // return this.http.post(this.rootURL2,{"UserName": "Demo user",
  //   "Email": "demomail@mail.com",
  //   "Phone": "1234567890",
  //   "Gender": "M",
  //   "Age": 28
  //  })
    
  }
  postEmployee2(formData2: EmployeeC){
    return this.http.post(this.rootURL2,formData2)
    .subscribe((data4)=>{console.log(data4)})
    //.subscribe(()=>{})
  }

  refreshList(){
    this.http.get(this.rootURL2)
    //this.http.get("https://dev.digisuvidhacentre.com/Profile/api/MockUser")
    .toPromise().then(res => this.list2 = res as EmployeeC[]);
    //return this.http.get("https://dev.digisuvidhacentre.com/Profile/api/MockUser")
    //return this.http.get(this.rootURL2);
  }

   deleteEmployee(id : number){
    // return this.http.delete(this.rootURL2+'/EmployeeC/'+id);
    return this.http.delete(this.rootURL2+'/Delete/'+id);
   }
}
